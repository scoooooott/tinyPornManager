#!/bin/bash
java -jar getdown.jar .